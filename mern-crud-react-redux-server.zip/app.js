const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const logger = require('morgan');
const mongoose = require('mongoose');
const SourceMapSuppoer = require('source-map-support');

//import router
const todoRouter=require('./server/routers/todoRouter');
const app = express();

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

//config
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(express.static(path.join(__dirname, 'public')));

//port
const port = process.env.PORT || 1234;

//connect to database
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://NhatThong:Asus22081997@productutorial-shard-00-00-iw3he.mongodb.net:27017,productutorial-shard-00-01-iw3he.mongodb.net:27017,productutorial-shard-00-02-iw3he.mongodb.net:27017/merntodo?ssl=true&replicaSet=productutorial-shard-0&authSource=admin&retryWrites=true', {
    useNewUrlParser: true
});
SourceMapSuppoer.install();

//use router
app.use('/',todoRouter);

app.use('/api',function(req,res){
    return res.end('API Working');
});

// catch 404
app.use((req, res, next) => {
    res.status(404).send('<h2 align=center>Page Not Found!</h2>');
});

app.listen(port, () => {
    console.log(`App listening on port ${port}!`);
});
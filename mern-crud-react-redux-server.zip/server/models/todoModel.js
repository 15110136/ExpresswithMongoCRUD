const mongoose=require('mongoose');

var TodoSchema=mongoose.Schema({
    createAt:{
        type:Date,
        default:Date.now
    },
    fullName:String,
    lastName:String
});

module.exports=mongoose.model('Todo',TodoSchema);
const express = require('express');

const todoController = require('../controllers/todoController');

const router = express.Router();

router.get('/test', todoController.test);

module.exports = router;
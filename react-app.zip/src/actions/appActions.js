export const toggleAddTodo=()=>{
    return{
        type:'TOGGLE_ADD_TODO'
    }
}
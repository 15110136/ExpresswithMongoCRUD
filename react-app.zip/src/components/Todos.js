import React from 'react';
import { Alert,Glyphicon,Button,Modal } from 'react-bootstrap';
import { Link } from 'react-router';

export default class Todos extends React.Component{
    constructor(props) {
      super(props)
    }
    
    componentWillMount() {
        this.props.fetchTodos();
    }
    showEditModal(bookToEdit) {
        //this.props.mappedshowEditModal(todoToEdit);
    }
    hideEditModal() {
        //this.props.mappedhideEditModal();
    }
    hideDeleteModal() {
        //this.props.mappedhideDeleteModal();
    }
    showDeleteModal(todoToDelete) {
        //this.props.mappedshowDeleteModal(todoToDelete);
    }
    render(){
        const todoState=this.props.mappedTodoState;
        const todos=todoState.todos;
        return(
            
        );
    }


}
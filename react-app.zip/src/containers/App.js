import {
    connect
} from 'react-redux';
import * as appActions from '../actions/appActions';
import App from '../components/App';

//map state from store to props
const mapStateToProps = (state) => {
    return {
        //this.prop.mappedAppState
        mappedAppState: state.appState
    }
}

//map action to props
const mapDispatchToProps = (dispatch) => {
    return {
        mappedToggleAddTodo:()=>dispatch(appActions.toggleAddTodo())
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(App);
